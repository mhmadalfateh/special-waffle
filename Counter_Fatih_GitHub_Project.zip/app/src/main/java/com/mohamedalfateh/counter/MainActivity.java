package com.mohamedalfateh.counter;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.content.Context;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        setContentView(new GameView(this));
    }

    class GameView extends View {
        Paint p = new Paint(3);
        int weapon = 0, team = 0, players = 4, ammo = 30, score = 0;
        float lookX = 0, lookY = 0;
        boolean settings = false, fireFlash = false;
        long flashUntil = 0;
        String[] weapons = {"مسدس", "رشاش خفيف", "رشاش ثقيل"};
        String[] grenades = {"دخانية", "ضوئية", "نارية"};
        String message = "أهلاً بك في Counter Fatih";
        float downX, downY, prevX, prevY;
        boolean draggingLook = false;
        GameView(Context c) { super(c); setFocusable(true); }
        void paint(Canvas c, int color) { p.setColor(color); p.setStyle(Paint.Style.FILL); }
        void text(Canvas c, String s, float x, float y, float size, int color) {
            paint(c, color); p.setTextSize(size); p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            c.drawText(s, x, y, p);
        }
        void box(Canvas c, float l,float t,float r,float b,int color,float rad) {
            paint(c,color); c.drawRoundRect(l,t,r,b,rad,rad,p);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(), h=getHeight();
            // Stylized first-person training arena with depth perspective.
            c.drawColor(Color.rgb(124,164,181));
            paint(c,Color.rgb(157,177,130)); c.drawRect(0,h*.43f,w,h,p);
            paint(c,Color.rgb(88,112,83));
            Path hills=new Path(); hills.moveTo(0,h*.45f); hills.lineTo(w*.16f,h*.25f); hills.lineTo(w*.31f,h*.43f); hills.lineTo(w*.52f,h*.20f); hills.lineTo(w*.72f,h*.43f); hills.lineTo(w*.88f,h*.29f); hills.lineTo(w,h*.44f); hills.close(); c.drawPath(hills,p);
            // Ground plane perspective
            paint(c,Color.rgb(119,127,92)); Path ground=new Path(); ground.moveTo(0,h*.49f); ground.lineTo(w,h*.49f); ground.lineTo(w,h); ground.lineTo(0,h); ground.close(); c.drawPath(ground,p);
            paint(c,Color.rgb(91,101,77)); Path road=new Path(); road.moveTo(w*.46f,h*.49f); road.lineTo(w*.54f,h*.49f); road.lineTo(w*.82f,h); road.lineTo(w*.18f,h); road.close(); c.drawPath(road,p);
            // Barriers / target dummies
            for(int i=0;i<5;i++){
                float x=w*(.12f+i*.18f), y=h*(.44f+(i%2)*.03f);
                box(c,x,y,x+70,y+32,Color.rgb(115,91,65),4);
                box(c,x+8,y-35,x+22,y+3,Color.rgb(63,73,59),3);
                box(c,x+2,y-48,x+28,y-24, team==0?Color.rgb(67,91,63):Color.rgb(169,184,190),8);
            }
            // First-person weapon silhouette
            box(c,w*.43f,h*.77f,w*.59f,h*1.04f,Color.rgb(43,47,45),14);
            box(c,w*.475f,h*.69f,w*.525f,h*.89f,Color.rgb(27,30,29),5);
            box(c,w*.455f,h*.82f,w*.545f,h*.91f,Color.rgb(72,78,72),5);
            // Crosshair
            paint(c,Color.WHITE); p.setStrokeWidth(3);
            float cx=w*.5f+(lookX%35), cy=h*.47f+(lookY%25);
            c.drawLine(cx-13,cy,cx-4,cy,p); c.drawLine(cx+4,cy,cx+13,cy,p);
            c.drawLine(cx,cy-13,cx,cy-4,p); c.drawLine(cx,cy+4,cx,cy+13,p);
            // HUD
            box(c,14,12,235,57,0xB9000000,12);
            text(c,"COUNTER FATIH",26,39,20,Color.WHITE);
            text(c,"المطور: محمد الفاتح",26,54,12,Color.WHITE);
            box(c,w-210,12,w-14,65,0xB9000000,12);
            text(c,weapons[weapon],w-196,37,17,Color.WHITE);
            text(c,"الذخيرة: "+ammo+"   النقاط: "+score,w-196,55,14,Color.WHITE);
            // touch controls
            box(c,20,h-118,155,h-22,0x99000000,18);
            text(c,"تحرّك",60,h-62,18,Color.WHITE);
            text(c,"◀  ▲  ▶",45,h-36,22,Color.WHITE);
            box(c,w-150,h-130,w-20,h-20,0xAA222222,65);
            text(c,"إطلاق",w-117,h-70,20,Color.WHITE);
            box(c,w-310,h-72,w-170,h-20,0xAA222222,15);
            text(c,"تبديل السلاح",w-295,h-40,15,Color.WHITE);
            box(c,w-470,h-72,w-320,h-20,0xAA222222,15);
            text(c,"قنبلة",w-430,h-40,17,Color.WHITE);
            box(c,18,70,190,112,0x99000000,12);
            text(c,team==0?"الفريق الأخضر":"الفريق الرملي",30,96,16,Color.WHITE);
            text(c,"لاعبون: "+players,30,108,12,Color.WHITE);
            box(c,205,12,360,52,0x99000000,10);
            text(c,settings?"الإعدادات":"اضغط ⚙ للإعدادات",215,35,14,Color.WHITE);
            if(fireFlash && System.currentTimeMillis()<flashUntil) {
                paint(c,0x88FFFFFF); c.drawRect(0,0,w,h,p);
                postInvalidateDelayed(80);
            } else fireFlash=false;
            if(settings) {
                box(c,w*.22f,h*.17f,w*.78f,h*.83f,0xEE172127,20);
                text(c,"الإعدادات",w*.43f,h*.25f,26,Color.WHITE);
                text(c,"عدد اللاعبين: "+players+"   (المحلي التجريبي)",w*.29f,h*.34f,19,Color.WHITE);
                text(c,"الصوت: اضغط على زر الصوت للتبديل",w*.29f,h*.42f,17,Color.WHITE);
                text(c,"الفريق: "+(team==0?"عسكري سوري (زي أخضر خيالي)":"فريق رملي (زي خيالي)"),w*.29f,h*.50f,17,Color.WHITE);
                text(c,"اللعب عبر نقطة الاتصال غير مفعّل بعد",w*.29f,h*.59f,17,0xFFFFD180);
                text(c,"اضغط هنا لإغلاق الإعدادات",w*.34f,h*.70f,18,Color.WHITE);
            }
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            float x=e.getX(), y=e.getY(); int w=getWidth(), h=getHeight();
            if(e.getAction()==MotionEvent.ACTION_DOWN) { downX=x; downY=y; prevX=x; prevY=y; return true; }
            if(e.getAction()==MotionEvent.ACTION_MOVE) {
                if(downX>w*.55f && downY<h*.72f) { lookX+=(x-prevX)*.45f; lookY+=(y-prevY)*.35f; invalidate(); }
                prevX=x; prevY=y; return true;
            }
            if(e.getAction()==MotionEvent.ACTION_UP) {
                if(settings) { settings=false; invalidate(); return true; }
                if(x<210 && y<125 && y>60) { settings=true; invalidate(); return true; }
                if(x>w-165 && y>h-150) { if(ammo>0){ammo--; score+=10; fireFlash=true; flashUntil=System.currentTimeMillis()+100; } else message="أعد التلقيم"; }
                else if(x>w-320 && x<w-160 && y>h-90) { weapon=(weapon+1)%weapons.length; ammo=weapon==0?12:30; }
                else if(x>w-480 && x<w-310 && y>h-90) { fireFlash=true; flashUntil=System.currentTimeMillis()+350; score+=5; }
                else if(x<170 && y>h-150) { lookX+= (x<85?-12:12); }
                else if(x>w-210 && y<75) { settings=true; }
                else if(x<190 && y<60) { team=1-team; }
                invalidate(); return true;
            }
            return true;
        }
    }
}
